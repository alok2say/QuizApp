# @alok2say/pdf-reader

A PDF reader you can drop into any web app as one HTML element,
`<pdf-reader>`. It works in React, Vue, Angular, Svelte, or a plain HTML
page, and comes with search, zoom, thumbnails, and page navigation.

It's built on [EmbedPDF](https://www.embedpdf.com/), which renders PDFs in
the browser with PDFium compiled to WebAssembly.

```html
<pdf-reader src="/docs/report.pdf" style="height: 80vh"></pdf-reader>
```

## Install

The package is published to GitHub Packages, which needs a token even to
install. Create a classic GitHub personal access token with the
`read:packages` scope, then add this to your app's `.npmrc`:

```ini
@alok2say:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

Keep the token in the `NODE_AUTH_TOKEN` environment variable. Don't
commit it.

```sh
NODE_AUTH_TOKEN=<your token> npm install @alok2say/pdf-reader
```

## Use it

### Any framework, or none

```js
import '@alok2say/pdf-reader' // registers <pdf-reader>
```

```html
<pdf-reader src="/docs/report.pdf" theme="system" style="height: 80vh"></pdf-reader>
```

To show a file the user picked, or one you downloaded yourself, set the
`source` property instead of `src`:

```js
const reader = document.querySelector('pdf-reader')
reader.source = fileInput.files[0] // File, Blob, ArrayBuffer, or a URL string
```

### Script tag, without a bundler

Copy `dist/pdf-reader.standalone.js` and `dist/pdfium.wasm` into your
site, side by side, then:

```html
<script type="module" src="/vendor/pdf-reader/pdf-reader.standalone.js"></script>
```

GitHub Packages isn't mirrored by public CDNs, so host these two files
yourself.

### React

```tsx
import { PdfReader } from '@alok2say/pdf-reader/react'

<PdfReader
  src="/docs/report.pdf"
  style={{ height: '80vh' }}
  onLoad={({ pageCount }) => console.log(pageCount)}
  onError={({ kind, message }) => console.warn(kind, message)}
/>
```

The adapter is marked `'use client'` and loads the reader only in the
browser, so it's safe to import from a Next.js server component.

## Options

| Attribute | Property | Default | What it does |
|---|---|---|---|
| `src` | `src` | none | URL of the PDF |
| — | `source` | `null` | A `File`, `Blob`, `ArrayBuffer`, or URL. Wins over `src`. |
| `theme` | `theme` | `system` | `light`, `dark`, or `system`. Changes apply without reloading. |
| `wasm-url` | `wasmUrl` | the bundled `pdfium.wasm` | Where to load the PDF engine from |
| `disabled-features` | — | `annotation,redaction,panel-comment` | Comma-separated EmbedPDF feature groups to turn off. An empty value turns everything on. |
| `load-timeout` | — | `30000` | Milliseconds to wait for the document before giving up |

Changing `src`, `source`, `wasm-url`, `disabled-features`, or
`load-timeout` reopens the reader.

## Events

All events bubble and cross shadow roots.

| Event | `event.detail` | When |
|---|---|---|
| `pdf-reader-load` | `{ pageCount }` | The document opened |
| `pdf-reader-pagechange` | `{ page, pageCount }` | The current page changed (`page` starts at 1) |
| `pdf-reader-error` | `{ kind, message }` | `kind` is `wasm` (engine couldn't load), `document` (PDF couldn't be opened), or `timeout` |

On an error the reader shows the message in place of the viewer, so it
never spins forever.

## Sizing

The reader fills its own box, so give it a height, for example
`style="height: 80vh"`. Without one it falls back to a minimum height of
24rem.

## Known limitations

- EmbedPDF keeps a small pool of 2 image-encoder workers per document
  that its API doesn't let us stop. The main PDF engine worker is
  stopped when the reader is removed or switches documents.
- PDFs that don't embed their fonts may load fallback fonts from
  jsdelivr.

## Licenses

MIT, see `LICENSE`. Bundled third-party software (EmbedPDF, PDFium) is
listed in `THIRD_PARTY_NOTICES`.
